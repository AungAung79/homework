LDAGibbsSampling
================

This is yangliuy's implementation for Gibbs Sampling of LDA. The test data set is Newsgroup-18828, which is included in the project. You can test other data sets with it. Just import the project into Eclipse and run LdaGibbsSampling.java to start it without any configuration. The original documents and sample output files have been included.

yangliuy' implementation for Gibbs Sampling of LDA is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Author's technical blog : http://blog.csdn.net/yangliuy

For more information of LDA and Gibbs Sampling: http://blog.csdn.net/yangliuy/article/details/8302599
