package liuyang.nlp.lda.conf;

public class PathConfig {

	public static String ldaDocsPath = "data/LdaOriginalDocs/";
	
	public static String LdaResultsPath = "data/LdaResults/";

}
