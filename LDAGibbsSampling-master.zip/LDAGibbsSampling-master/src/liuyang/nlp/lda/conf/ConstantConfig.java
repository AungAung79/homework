package liuyang.nlp.lda.conf;

public class ConstantConfig {
	
	public static String LDAPARAMETERFILE = "data/LdaParameter/LdaParameters.txt";

}
