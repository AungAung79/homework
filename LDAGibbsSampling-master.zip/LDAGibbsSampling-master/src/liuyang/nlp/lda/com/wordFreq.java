package liuyang.nlp.lda.com;

import java.util.ArrayList;


public class wordFreq {

	public String word;

	public int No;
	
	public double prob;
	
	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getNo() {
		return No;
	}

	public void setNo(int no) {
		No = no;
	}

	public double getProb() {
		return prob;
	}

	public void setProb(double prob) {
		this.prob = prob;
	}
	
}
