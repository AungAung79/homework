package liuyang.nlp.lda.script;

/**Data preprocess for documents
 * Mainly do tokenization by Stanford tokenizer
 * @author yangliu
 * @blog http://blog.csdn.net/yangliuy
 * @mail yangliuyx@gmail.com
 */
public class DataPreprocess {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
